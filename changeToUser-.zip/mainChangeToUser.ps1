﻿##[Ps1 To Exe]
##
##NcDBCIWOCzWE8pGP3wFk4Fn9fkIkfcCLsZyvy4+b/ubotBn2R58wW11hk2mxRGC8V+YTW/sU9PgfUxI4IvMf673eW9OsRqoEne9wbPyygrc6Hk7X86/33Becyp7UMT9SRFXpaa5aEi74zGDTTGimioxoi2SwZsHUuJt0+0uLhhw=
##Kd3HDZOFADWE8uK1
##Nc3NCtDXThU=
##Kd3HFJGZHWLWoLaVvnQnhQ==
##LM/RF4eFHHGZ7/K1
##K8rLFtDXTiW5
##OsHQCZGeTiiZ4tI=
##OcrLFtDXTiW5
##LM/BD5WYTiiZ4tI=
##McvWDJ+OTiiZ4tI=
##OMvOC56PFnzN8u+Vs1Q=
##M9jHFoeYB2Hc8u+Vs1Q=
##PdrWFpmIG2HcofKIo2QX
##OMfRFJyLFzWE8uK1
##KsfMAp/KUzWJ0g==
##OsfOAYaPHGbQvbyVvnQX
##LNzNAIWJGmPcoKHc7Do3uAuO
##LNzNAIWJGnvYv7eVvnQX
##M9zLA5mED3nfu77Q7TV64AuzAgg=
##NcDWAYKED3nfu77Q7TV64AuzAgg=
##OMvRB4KDHmHQvbyVvnQX
##P8HPFJGEFzWE8tI=
##KNzDAJWHD2fS8u+Vgw==
##P8HSHYKDCX3N8u+Vgw==
##LNzLEpGeC3fMu77Ro2k3hQ==
##L97HB5mLAnfMu77Ro2k3hQ==
##P8HPCZWEGmaZ7/K1
##L8/UAdDXTlaDjofG5iZk2WHhUW07Zu+TtriAxY248NbDtSD9W5MCTBQ61gL9Cl+8V/wTFdwbst4DWBw+Jv0FoobVGO+nSq4FlfpDT+CdraYmBWbb7J361hqG4K7wDAV0U1D6a6d8HSrVw2ThammXgIpbgHW6WcuvroZj1Q==
##Kc/BRM3KXhU=
##
##
##fd6a9f26a06ea3bc99616d4851b372ba
$username = 'azuread\joseph.galdo@kantanna.com'
$password = 'iamforMB2019!!!' 
$securePassword = ConvertTo-SecureString $password -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential $username, $securePassword

$user=Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object UserName


$name = $user.UserName
$name | out-file -filePath $env:TEMP\name.txt
Start-Process powershell -Credential $Credential -ArgumentList "-noprofile", "-command", "Start-Process cmd.exe -Verb RunAs -ArgumentList /C, 'cd $env:TEMP && powershell -noprofile -executionpolicy bypass -file .\changeToUser.ps1'" -WorkingDirectory 'C:\WINDOWS\System32'