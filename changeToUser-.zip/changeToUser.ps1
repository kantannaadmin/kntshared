Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force

$1 =Get-Content -Path .\name.txt

Add-LocalGroupMember -group "Users" -member $1

Remove-LocalGroupMember -group "Administrators" -member $1

Remove-Item -Path .\name.txt
Remove-Item *.ps1
Remove-Item -Path .\changeToUser.zip