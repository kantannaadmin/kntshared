﻿################### INSTALLATION OF CREDENTIAL MANAGER ###################
$credentialManager = Get-Module -ListAvailable -Name CredentialManager
if ($credentialManager -eq $null) {
    Install-Module CredentialManager -force -Scope CurrentUser
    start-sleep -Seconds 15
    Import-Module -Name CredentialManager
    start-sleep -Seconds 15
    Write-Output "Credential Manager Module is already installed and imported"
}else{
    Write-Output "Credential Manager Module is already installed"
}

################### CREATING IT ADMIN CREDENTIAL ###################
$target = "IT_Admin_Credential"
$getStoredCredential = Get-StoredCredential -Target $target
if($getStoredCredential -eq $null){
    $t = New-StoredCredential -Target $target -UserName "azuread\knt.locadmin@connectos.com.au" -Password "2a9E-RTxbi6dqDK8nMI" -Persist LocalMachine
    Write-Output "IT admin credential is already installed"
    start-sleep -Seconds 15
}else{
    Write-Output "IT admin credential is already stored"   
}



$target = "IT_Admin_Credential"
$credential = Get-StoredCredential -Target $target

$user=Get-CimInstance -ClassName Win32_ComputerSystem | Select-Object UserName



$name = $user.UserName
$name | out-file -filePath .\name.txt
$fileLoc = $env:Temp

Start-Process powershell -Credential $Credential -ArgumentList "-noprofile", "-command", "Start-Process cmd.exe -Verb RunAs -ArgumentList /C, 'cd $fileLoc && powershell -noprofile -executionpolicy bypass -file .\changeToAdmin.ps1'" -WorkingDirectory 'C:\WINDOWS\System32'