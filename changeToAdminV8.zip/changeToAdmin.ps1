﻿$scriptpath = $MyInvocation.MyCommand.Path
$dir = Split-Path $scriptpath
################## Create C2U folder in C drive ##################
$directory = New-Item -Path "C:\" -Name "C2A" -ItemType "directory"

################## Change Group Command ##################
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
$1 =Get-Content -Path .\name.txt
Add-LocalGroupMember -group "Administrators" -member $1
Remove-LocalGroupMember -group "Users" -member $1

################## Create output ##################
$output = net localgroup administrators
$output | Out-File -FilePath "C:\C2A\output.txt"

################## Remove files in Temp folder ##################
Remove-Item -Path .\name.txt
Remove-Item *.ps1
Remove-Item .\changeToAdmin.zip
$C2UFolder = Test-Path "C:\C2U"
if($C2UFolder -eq $true){
Remove-Item "C:\C2U" -Recurse
}else{
Write-output "C2U folder does not exist"
}